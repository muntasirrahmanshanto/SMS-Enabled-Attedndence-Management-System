# SMS-Enabled-Attedndence-Management-System
This is a modified version of the biometric attendance project Using the R307 fingerprint sensor and SIM 800L module. SIM 800L pin configuration is in the code.
In the original project, there wasn't available the sms notification function. I have added the SMS functionality in the node MCU code and the website file. If you want to test it, set up the website and upload the nodeMCU code in your node MCU. Don't forget to replace the country code. By default, it is "+880". Replace this with your own country code.
Required Hardware:

SIM800L Module

R307 Fingerprint sensor

NodeMCU (ESP 8266)

5V 2A powersource for SIM800L Module.

ETC

** IMPORTANT ** 
 *** I have given a required library. I tried to upload codes with Arduino IDE but It didn't work. But It was successfully uploaded with ARDUINO ONLINE IDE *** 
The original video I followed for this project: https://www.youtube.com/watch?v=4pQtER8PShw

Credit Goes To Electronic Tech YouTube channel. : https://www.youtube.com/@ElectronicsTechHaIs
